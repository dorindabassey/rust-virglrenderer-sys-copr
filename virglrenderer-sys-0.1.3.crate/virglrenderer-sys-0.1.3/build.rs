use std::{env, path::PathBuf};

fn main() {
    // Rebuild when env or wrapper changes.
    println!("cargo:rerun-if-env-changed=DOCS_RS");
    println!("cargo:rerun-if-changed=wrapper.h");

    // On docs.rs: don't run pkg-config or bindgen, just set a cfg.
    if env::var("DOCS_RS").is_ok() {
        println!("cargo:rustc-cfg=docsrs");
        return;
    }

    // Normal builds: find virglrenderer via pkg-config.
    let lib = pkg_config::Config::new()
        .atleast_version("0.10")
        .probe("virglrenderer")
        .unwrap_or_else(|e| {
            eprintln!(
                "ERROR: {e}\n\
                 virglrenderer dev headers not found. Install e.g.:\n\
                 - Debian/Ubuntu:  sudo apt-get install libvirglrenderer-dev\n\
                 - Fedora:         sudo dnf install virglrenderer-devel\n\
                 - Arch:           sudo pacman -S virglrenderer\n"
            );
            std::process::exit(1);
        });

    // Pass include paths to clang for bindgen.
    let clang_includes: Vec<String> = lib
        .include_paths
        .iter()
        .map(|p| format!("-I{}", p.display()))
        .collect();

    // Generate bindings from wrapper.h
    let out = PathBuf::from(env::var("OUT_DIR").unwrap());
    let bindings = bindgen::Builder::default()
        .header("wrapper.h")
        .clang_arg("-DVIRGL_RENDERER_UNSTABLE_APIS")
        .clang_args(clang_includes)
        .parse_callbacks(Box::new(bindgen::CargoCallbacks::new()))
        .generate()
        .expect("bindgen failed");
    bindings
        .write_to_file(out.join("bindings.rs"))
        .expect("write bindings.rs");

    // Link flags from pkg-config
    for p in &lib.link_paths {
        println!("cargo:rustc-link-search=native={}", p.display());
    }
    for name in &lib.libs {
        println!("cargo:rustc-link-lib={}", name);
    }
}
